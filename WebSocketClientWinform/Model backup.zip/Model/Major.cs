﻿namespace UDPServerAndWebSocketClient
{
    public enum Major
    {
        LoRaWAN_R1,
        RFU
    }
}