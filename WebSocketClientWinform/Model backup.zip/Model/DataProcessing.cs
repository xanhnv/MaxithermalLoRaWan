﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using UDPServerAndWebSocketClient.Model;

namespace UDPServerAndWebSocketClient
{

    /// <summary>
    /// Processing data and save to DB
    /// </summary>
    public class DataProcessing
    {
        //Pexo63LorawanEntities db = new Pexo63LorawanEntities();
        Setting setting = new Setting();
        private Alarm alarmSet;
        private string Status;

        string GetStatus(byte dt)
        {
            string status = "";
            switch (dt)
            {
                case 0xff:
                    status = "no setting & no run";
                    break;
                case 0x11:
                    status = "setting & no run";
                    break;
                case 0x44:
                    status = "running";
                    break;
                case 0xAA:
                    status = "stop";
                    break;
                case 0xDD:
                    status = "delaying";
                    break;
            }
            return status;
        }

        public bool CheckExistDevice(byte[] devAdd)
        {
            using (var db = new Pexo63LorawanEntities())
            {
                foreach (var item in db.Devices)
                {
                    if (item.DeviceAddress.SequenceEqual(devAdd))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        string GetDeviceType(byte dt)
        {
            string deviceType = "";
            switch (dt)
            {
                case 0x11:
                    deviceType = "Humidity, Room temperature";
                    break;
                case 0x22:
                    deviceType = "Humidity, LN2";
                    break;
                case 0x33:
                    deviceType = "Humidity, RTD2";
                    break;
                case 0x44:
                    deviceType = "LN2, Room Temperature";
                    break;
                case 0x55:
                    deviceType = "RTD2, Room temperature";
                    break;
                case 0x66:
                    deviceType = "Thermal couple, Humidity (%)";
                    break;
                case 0x77:
                    deviceType = "Room temperature, Thermal couple";
                    break;
            }
            return deviceType;
        }
        public double convertTemFrom15bit(double num, int coefficient)
        {
            if (num > 32767D)
                return num;
            if (num < 0)
                return 0;
            if (num <= 16383D)
                return (num / coefficient);
            return ((num - 32768D) / coefficient);
        }

        public void GetRealtimeData(byte[] data, string Serial)
        {
            Data dt = new Data();
            dt.Serial = Serial;
            //try
            //{
            //    //dt.Time = new DateTime(data[14] + 2000, data[13], data[12], data[11], data[10], data[9]); //code cu, lay thoi gian cua logger
            //    dt.Time = new DateTime(data[14] + 2000, data[13], data[12], data[11], data[10], data[9]);//code moi, lay thoi gian cua may tinh
            //}
            //catch
            //{
            //    dt.Time = new DateTime();
            //}

            dt.Data1 = convertTemFrom15bit((data[21] + data[22] * 256), 10);

            dt.Data2 = convertTemFrom15bit((data[23] + data[24] * 256), 10);


            //get Runtime 
            string runtime = "";
            TimeSpan tspRuntime;
            try
            {
                tspRuntime = new TimeSpan(data[19] * 256 + data[18], data[17], data[16], data[15]);
            }
            catch
            {
                tspRuntime = new TimeSpan();
            }
            runtime = tspRuntime.ToString();
            //get status 
            string status = GetStatus(data[20]);

            //save Realtime Table
            try
            {
                using (var db = new Pexo63LorawanEntities())
                {
                    //Check exis Data on table Data
                    var newestData = db.Data1.OrderByDescending(u => u.ID).Where(u => u.Serial == Serial).FirstOrDefault();
                    if (newestData != null)
                    {
                        if (newestData.Time.Equals(dt.Time))
                        {
                            return;
                        }
                    }
                    var recordSt = db.Settings.Where(s => s.Serial == Serial).FirstOrDefault<Setting>();
                    if (recordSt == null)
                    {
                        return;
                    }
                    DateTime now = DateTime.Now;

                    if (recordSt.TimezoneId != null)
                    {
                        now = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(now, TimeZoneInfo.Local.Id, recordSt.TimezoneId);
                        dt.Time = now;
                    }
                    else
                    {
                        try
                        {
                            dt.Time = new DateTime(data[14] + 2000, data[13], data[12], data[11], data[10], data[9]);
                        }
                        catch
                        {
                            dt.Time = new DateTime();
                        }
                    }

                    var record = db.Realtimes.Include(a => a.Setting).FirstOrDefault<Realtime>(u => u.Serial == Serial);
                    if (record != null) //update
                    {
                        string unit = record.Setting.Unit == "Celsius" ? "°C " : "°F";
                        record.Runtime = runtime;
                        record.Status = status;
                        record.Data1 = dt.Data1.ToString();// + unit;
                        record.Data2 = dt.Data2.ToString();// + "%";
                        record.TimeUpdated = dt.Time.ToString("MMM d HH:mm:ss") + GetTimezoneUTC(Serial);
                    }
                    else //add new
                    {
                        db.Realtimes.Add(new Realtime()
                        {

                            Data1 = dt.Data1.ToString(),
                            Data2 = dt.Data2.ToString(),
                            Runtime = runtime,
                            Serial = Serial,
                            Status = status,
                            TimeUpdated = dt.Time.ToString("MMM d HH:mm:ss") + GetTimezoneUTC(Serial)
                        });
                    }
                    db.Data1.Add(dt);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Utilities.WriteLogError(ex);
            }
        }
        public void GetAlarmData(byte[] data, string Serial)
        {
            try
            {
                Alarm alarms = new Alarm();
                alarms.Serial = Serial;
                alarms.TttAlarm1 = new TimeSpan(data[30] * 256 + data[29], data[28], data[27], data[26]).TotalSeconds;
                alarms.TttLowAlarm1 = new TimeSpan(data[35] * 256 + data[34], data[33], data[32], data[31]).TotalSeconds;
                alarms.TttAlarm2 = new TimeSpan(data[40] * 256 + data[39], data[38], data[37], data[36]).TotalSeconds;
                alarms.TttLowAlarm2 = new TimeSpan(data[45] * 256 + data[44], data[43], data[42], data[41]).TotalSeconds;
                alarms.TimeUpdated = new DateTime(data[20], data[19], data[18], data[17], data[16], data[15]).ToString("MMM d HH:mm:ss") + GetTimezoneUTC(Serial);//Stop time

                var StartTime = new DateTime(data[14] + 2000, data[13], data[12], data[11], data[10], data[9]);
                //get Runtime 
                string runtime = new TimeSpan(data[25] * 256 + data[24], data[23], data[22], data[21]).ToString();
                var Data1 = convertTemFrom15bit((data[46] + data[47] * 256), 10);
                var Data2 = convertTemFrom15bit((data[48] + data[49] * 256), 10);

                //Add or Update to Realtime Table
                using (var db = new Pexo63LorawanEntities())
                {
                    #region Check record in DB
                    var alarmDB = db.Alarms.FirstOrDefault<Alarm>(u => u.Serial == Serial);
                    var recordSt = db.Settings.Where(s => s.Serial == setting.Serial).FirstOrDefault<Setting>();
                    if (recordSt == null)
                    {
                        return;
                    }
                    if (alarmDB.TimeUpdated == alarms.TimeUpdated)
                    {
                        return;
                    }
                    #endregion
                    #region Update realtime table
                    var realtime = db.Realtimes.Include(a => a.Setting).FirstOrDefault<Realtime>(u => u.Serial == Serial);
                    if (realtime != null) //not exis
                    {
                        string unit = realtime.Setting.Unit == "Celsius" ? "°C " : "°F";
                        //update to db Settings
                        realtime.Runtime = runtime;
                        realtime.Data1 = Data1.ToString();// + unit;
                        realtime.Data2 = Data2.ToString();// + "%";
                        realtime.Status = "running";
                        realtime.TimeUpdated = alarms.TimeUpdated;
                    }
                    else //ko xay ra 
                    {
                        db.Realtimes.Add(new Realtime()
                        {
                            Data1 = Data1.ToString(),
                            Data2 = Data2.ToString(),
                            Runtime = runtime,
                            Serial = Serial,
                            Status = "running",
                            TimeUpdated = alarms.TimeUpdated
                        });
                    }
                    #endregion
                    var Alarmrecord = db.Alarms.Where(s => s.Serial == alarms.Serial).FirstOrDefault<Alarm>();
                    if (Alarmrecord == null) //not exis (kho xay ra)
                    {
                        // Thêm vào bang Alarm
                        db.Alarms.Add(alarms);
                        SendEmail(alarms);
                    }
                    else
                    {

                        if (Alarmrecord.TttAlarm1 < alarms.TttAlarm1 || Alarmrecord.TttAlarm2 < alarms.TttAlarm2)
                        {
                            //send email
                            SendEmail(alarms);
                            //Cap nhat DB
                            Alarmrecord.TttAlarm1 = alarms.TttAlarm1;
                            Alarmrecord.TttAlarm2 = alarms.TttAlarm2;
                            Alarmrecord.TttLowAlarm1 = alarms.TttLowAlarm1;
                            Alarmrecord.TttLowAlarm2 = alarms.TttLowAlarm2;
                            Alarmrecord.TimeUpdated = alarms.TimeUpdated;
                        }
                    }

                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Last update error: " + ex.Message);
                Utilities.WriteLogError(ex);
            }
        }
        public void GetSeting1(byte[] data, string Serial)
        {
            //string deviceType = GetDeviceType(data[8]);
            setting = new Setting();
            setting.SettingByLora = false;
            setting.Devicetype = data[8];
            setting.Serial = Serial;

            if (data[9] == 0xAC)
            {
                setting.Unit = "Celsius";
                setting.Celsius = true;
            }
            else
            {
                setting.Celsius = false;
                setting.Unit = "Farenheit";
            }
            // continue menory, stopkey
            switch (data[10])
            {
                case 0:
                    setting.ContinueMem = false;
                    setting.Stopkey = true;
                    break;
                case 1:
                    setting.ContinueMem = false;
                    setting.Stopkey = false;
                    break;
                case 2:
                    setting.ContinueMem = true;
                    setting.Stopkey = true;
                    break;
                case 3:
                    setting.ContinueMem = true;
                    setting.Stopkey = false;
                    break;
                default:
                    setting.ContinueMem = false;
                    setting.Stopkey = false;
                    break;
            }
            Status = GetStatus(data[28]);
            try
            {
                setting.Settingtime = new DateTime(data[34] + 2000, data[33], data[32], data[31], data[30], data[29]).ToString();
                setting.Starttime = new DateTime(data[16] + 2000, data[15], data[14], data[13], data[12], data[11]).ToString();
                if (data[17] != 255 & data[17] < 60)
                {
                    setting.Stoptime = new DateTime(data[22] + 2000, data[21], data[20], data[19], data[18], data[17]).ToString();
                }
            }
            catch
            {
                Console.WriteLine("Parse datetime error");
            }

            setting.Delay = data[35];
            setting.DurationDay = (data[36] + data[37] * 256);
            setting.DurationHour = data[38];
            setting.IntervalHour = data[39];
            setting.IntervalMin = data[40];
            setting.IntervalSec = data[41];
            setting.FirmwareVer = "v " + data[50] + "." + data[51];
            //Alarm
            alarmSet = new Alarm();
            alarmSet.Serial = Serial;
            alarmSet.HighAlarmTemp = (data[42] + data[43] * 256) / 10.0;
            alarmSet.LowAlarmTemp = (data[44] + data[45] * 256) / 10.0;
            alarmSet.HighAlarmHumid = (data[46] + data[47] * 256) / 10.0;
            alarmSet.LowAlarmHumid = (data[48] + data[49] * 256) / 10.0;
            if (alarmSet.HighAlarmTemp == 1000.0 && alarmSet.LowAlarmTemp == 1000.0)
            {
                alarmSet.AlarmStatus1 = false;
            }
            else
            {
                alarmSet.AlarmStatus1 = true;
            }

            if (alarmSet.HighAlarmHumid == 1000.0 && alarmSet.LowAlarmHumid == 1000.0)
            {
                alarmSet.AlarmStatus2 = false;
            }
            else
            {
                alarmSet.AlarmStatus2 = true;
            }
            alarmSet.TttAlarm1 = 0;
            alarmSet.TttAlarm2 = 0;
            alarmSet.TttLowAlarm1 = 0;
            alarmSet.TttLowAlarm2 = 0;
            alarmSet.TimeUpdated = DateTime.Now.ToString("MMM d HH:mm:ss") + GetTimezoneUTC(Serial);
            //Update to tbl  REaltime and Alarms
            using (var db = new Pexo63LorawanEntities())
            {



                db.SaveChanges();
            }
        }
        string GetTimezoneUTC(string Serial)
        {
            using (var db = new Pexo63LorawanEntities())
            {
                var record = db.Settings.Where(s => s.Serial == Serial).FirstOrDefault<Setting>();
                if (record != null)
                {
                    if (record.TimezoneId != null)
                    {
                        TimeZoneInfo infoTimezone = TimeZoneInfo.FindSystemTimeZoneById(record.TimezoneId);
                        return infoTimezone.DisplayName.Substring(0, 11);
                    }
                }
            }
            return null;
        }
        public void GetSeting2(byte[] data, string Serial)
        {
            //Get timezone 40byte
            string timezone = Encoding.ASCII.GetString(data, 9, 40).Replace("\0", "").Trim();
            System.Collections.ObjectModel.ReadOnlyCollection<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            foreach (TimeZoneInfo zone in zones)
            {
                if (zone.Id.Contains(timezone))
                {
                    setting.TimezoneId = zone.Id;
                    break;
                }
            }
            if (setting.TimezoneId == null)
            {
                setting.TimezoneId = TimeZoneInfo.Local.Id;
            }

            Console.WriteLine("Timezone ID: " + setting.TimezoneId);
        }
        public void GetSeting3(byte[] data, string Serial)
        {
            //Get Description
            setting.Description = Encoding.ASCII.GetString(data, 9, 20).Replace("\0", "");
            setting.IntervalSendLoraMin = data[31];
            setting.IntervalSendLoraHour = data[30];
            setting.IntervalSendLoraDay = data[29];
            //Console.WriteLine("Descrtion: " + descrtiptin);
            //update or insert to database
            using (var db = new Pexo63LorawanEntities())
            {

                var record = db.Settings.Where(s => s.Serial == setting.Serial).FirstOrDefault<Setting>();
                var itemDelete = db.Data1.Where(dt => dt.Serial == Serial);
                if (itemDelete != null)
                {
                    db.Data1.RemoveRange(itemDelete);
                }

                if (record == null) //not exis
                {
                    // Thêm vào database
                    db.Settings.Add(setting);
                }
                else
                {
                    //Cap nhat
                    record.Description = setting.Description;
                    record.DurationDay = setting.DurationDay;
                    record.DurationHour = setting.DurationHour;
                    record.FirmwareVer = setting.FirmwareVer;
                    record.IntervalSec = setting.IntervalSec;
                    record.IntervalMin = setting.IntervalMin;
                    record.IntervalHour = setting.IntervalHour;

                    record.Settingtime = setting.Settingtime;
                    record.Starttime = setting.Starttime;
                    record.Stoptime = setting.Stoptime;
                    record.Unit = setting.Unit;
                    record.Devicetype = setting.Devicetype;
                    record.TimezoneId = setting.TimezoneId;
                    record.IntervalSendLoraMin = setting.IntervalSendLoraMin;
                    record.IntervalSendLoraDay = setting.IntervalSendLoraDay;
                    record.IntervalSendLoraHour = setting.IntervalSendLoraHour;
                    record.SettingByLora = setting.SettingByLora;
                }

                //real time
                string Runtime = new TimeSpan().ToString();// new TimeSpan(data[27] * 256 + data[26], data[25], data[24], data[23]).ToString();

                var realtime = db.Realtimes.FirstOrDefault<Realtime>(u => u.Serial == Serial);
                if (realtime != null) //upadte or insert
                {
                    realtime.Serial = Serial;
                    realtime.Runtime = Runtime;
                    realtime.Status = Status;
                    realtime.Data1 = null;
                    realtime.Data2 = null;
                    realtime.TimeUpdated = DateTime.Now.ToString("MMM d HH:mm:ss") + GetTimezoneUTC(Serial);
                }
                else
                {
                    db.Realtimes.Add(new Realtime()
                    {
                        Runtime = Runtime,
                        Serial = Serial,
                        Status = Status,
                        Data1 = null,
                        Data2 = null,
                        TimeUpdated = DateTime.Now.ToString("MMM d HH:mm:ss") + GetTimezoneUTC(Serial)
                    });
                }
                //alarm
                var alarm = db.Alarms.FirstOrDefault<Alarm>(u => u.Serial == Serial);
                if (alarm != null) //update
                {
                    //alarm = alarmSet;
                    alarm.Serial = Serial;
                    alarm.HighAlarmTemp = alarmSet.HighAlarmTemp;
                    alarm.LowAlarmTemp = alarmSet.LowAlarmTemp;
                    alarm.HighAlarmHumid = alarmSet.HighAlarmHumid;
                    alarm.LowAlarmHumid = alarmSet.LowAlarmHumid;
                    alarm.TttAlarm1 = 0;
                    alarm.TttAlarm2 = 0;
                    alarm.TttLowAlarm1 = 0;
                    alarm.TttLowAlarm2 = 0;
                    alarm.AlarmStatus1 = alarmSet.AlarmStatus1;
                    alarm.AlarmStatus2 = alarmSet.AlarmStatus2;
                    alarm.TimeUpdated = DateTime.Now.ToString("MMM d HH:mm:ss") + GetTimezoneUTC(Serial);
                }
                else //add new record
                {
                    db.Alarms.Add(alarmSet);

                }

                try
                {
                    db.SaveChanges();
                }
                catch (Exception ex)
                {
                    Utilities.WriteLogError(ex);
                }
            }

        }
        public void GetEndSetting(byte[] data, string Serial)
        {
            try
            {
                //Start time
                var StartTime = new DateTime(data[14] + 2000, data[13], data[12], data[11], data[10], data[9]);
                //Stop time
                var StopTime = new DateTime(data[20] + 2000, data[19], data[18], data[17], data[16], data[15]);
                //get Runtime 
                string runtime = new TimeSpan(data[25] * 256 + data[24], data[23], data[22], data[21]).ToString();
                //alarm time
                Alarm alarms = new Alarm();
                alarms.Serial = Serial;
                alarms.TttAlarm1 = new TimeSpan(data[30] * 256 + data[29], data[28], data[27], data[26]).TotalSeconds;
                alarms.TttLowAlarm1 = new TimeSpan(data[35] * 256 + data[34], data[33], data[32], data[31]).TotalSeconds;
                alarms.TttAlarm2 = new TimeSpan(data[40] * 256 + data[39], data[38], data[37], data[36]).TotalSeconds;
                alarms.TttLowAlarm2 = new TimeSpan(data[45] * 256 + data[44], data[43], data[42], data[41]).TotalSeconds;
                alarms.TimeUpdated = StopTime.ToString("MMM d HH:mm:ss");//Stop time
                                                                         //Data realtime
                var Data1 = convertTemFrom15bit((data[46] + data[47] * 256), 10);
                var Data2 = convertTemFrom15bit((data[48] + data[49] * 256), 10);

                //Add or Update to Realtime Table
                using (var db = new Pexo63LorawanEntities())
                {
                    var recordSt = db.Settings.Where(s => s.Serial == setting.Serial).FirstOrDefault<Setting>();
                    if (recordSt == null)
                    {
                        return;
                    }
                    var realtime = db.Realtimes.Include(a => a.Setting).FirstOrDefault<Realtime>(u => u.Serial == Serial);
                    if (realtime != null) //not exis
                    {
                        string unit = realtime.Setting.Unit == "Celsius" ? "°C " : "°F";
                        //update to db Settings
                        realtime.Runtime = runtime;
                        realtime.Data1 = Data1.ToString();// + unit;
                        realtime.Data2 = Data2.ToString();// + "%";
                        realtime.Status = "stop";
                        realtime.TimeUpdated = alarms.TimeUpdated;
                    }
                    //update alarm table
                    var Alarmrecord = db.Alarms.Where(s => s.Serial == alarms.Serial).FirstOrDefault<Alarm>();
                    if (Alarmrecord == null) //not exis (kho xay ra)
                    {
                        // Thêm vào bang Alarm
                        db.Alarms.Add(alarms);
                        SendEmail(alarms);
                    }
                    else
                    {
                        //
                        if (Alarmrecord.TttAlarm1 < alarms.TttAlarm1 || Alarmrecord.TttAlarm2 < alarms.TttAlarm2)
                        {
                            //send email
                            // SendEmail(alarms);
                            //Cap nhat DB
                            Alarmrecord.TttAlarm1 = alarms.TttAlarm1;
                            Alarmrecord.TttAlarm2 = alarms.TttAlarm2;
                            Alarmrecord.TttLowAlarm1 = alarms.TttLowAlarm1;
                            Alarmrecord.TttLowAlarm2 = alarms.TttLowAlarm2;
                            Alarmrecord.TimeUpdated = alarms.TimeUpdated;
                        }
                    }
                    //update settings table
                    var settingRecord = db.Settings.Where(s => s.Serial == Serial).FirstOrDefault<Setting>();
                    if (settingRecord != null) //not exis (kho xay ra)
                    {
                        setting.Stoptime = StopTime.ToString();
                    }
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Last update error: " + ex.Message);
                Utilities.WriteLogError(ex);
            }
        }
        public void SendEmail(Alarm alarm)
        {
            var myemail = "marathonlorawan@gmail.com";
            const string fromPassword = "MarathonDgs";
            string subject = "Alarm occurs from logger: " + alarm.Serial;
            var db = new Pexo63LorawanEntities();
            var settingRecord = db.Settings.Include(u => u.Realtime).FirstOrDefault<Setting>(s => s.Serial == alarm.Serial);
            if (settingRecord == null) //not exis
            {
                return;
            }
            string unit2 = "", channel2name = "", channel1name = "";
            if (settingRecord.Devicetype == 0x44 || settingRecord.Devicetype == 0x55 || settingRecord.Devicetype == 0x77)
            {
                unit2 = settingRecord.Unit;

            }
            else
            {
                unit2 = "%";

            }
            string[] deviceType = GetDeviceType(settingRecord.Devicetype).Split(',');
            channel1name = deviceType[1].TrimStart();
            channel2name = deviceType[0];
            if (settingRecord.Email != null)
            {
                try
                {
                    MailMessage mail = new MailMessage();
                    SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                    mail.From = new MailAddress(myemail);
                    mail.To.Add(settingRecord.Email);
                    mail.Subject = subject;
                    mail.Body = "This is a warning email sent automatically from Lorawan server when logger: \"" + alarm.Serial + "\" exceeds the limit.\r\n";

                    mail.Body += channel1name + " enable alarm: " + alarm.AlarmStatus1 + "\r\n";
                    if (alarm.AlarmStatus1)
                    {
                        mail.Body += "- High alarm: " + alarm.HighAlarmTemp + " " + settingRecord.Unit + "\r\n";
                        mail.Body += "- Low alarm: " + alarm.LowAlarmTemp + " " + settingRecord.Unit + "\r\n";
                    }
                    mail.Body += channel2name + " enable alarm: " + alarm.AlarmStatus2 + "\r\n";
                    if (alarm.AlarmStatus2)
                    {
                        mail.Body += "- High alarm: " + alarm.HighAlarmHumid + " " + unit2 + "\r\n";
                        mail.Body += "- Low alarm: " + alarm.LowAlarmHumid + " " + unit2 + "\r\n";
                    }
                    else
                    {
                        mail.Body += "- High alarm: " + "No alarm" + "\r\n";
                        mail.Body += "- Low alarm: " + "No  alarm" + "\r\n";
                    }
                    mail.Body += "- Current " + channel1name + ": " + settingRecord.Realtime.Data1 + " " + settingRecord.Unit + "\r\n";
                    mail.Body += "- Current " + channel2name + ": " + settingRecord.Realtime.Data2 + " " + settingRecord.Unit + "\r\n";
                    mail.Body += "- Total time high alarm " + channel1name + ": " + TimeSpan.FromSeconds(alarm.TttAlarm1 - alarm.TttLowAlarm1).ToString() + "\r\n";
                    mail.Body += "- Total time low alarm " + channel1name + ": " + TimeSpan.FromSeconds(alarm.TttLowAlarm1).ToString() + "\r\n";
                    mail.Body += "- Total time high alarm " + channel2name + ": " + TimeSpan.FromSeconds(alarm.TttAlarm1 - alarm.TttLowAlarm2).ToString() + "\r\n";
                    mail.Body += "- Total time low alarm " + channel2name + ": " + TimeSpan.FromSeconds(alarm.TttLowAlarm2).ToString() + "\r\n";
                    mail.Body += "- Start time: " + settingRecord.Starttime + "\r\n";
                    mail.Body += "- Run time: " + settingRecord.Realtime.Runtime + "\r\n";
                    mail.Body += "- Time updated: " + alarm.TimeUpdated + "\r\n";

                    mail.Body += "For more information please visit the website: http://113.161.71.163/";
                    mail.Priority = MailPriority.High;
                    SmtpServer.Port = 587;
                    SmtpServer.Credentials = new System.Net.NetworkCredential(myemail, fromPassword);
                    SmtpServer.EnableSsl = true;
                    SmtpServer.Send(mail);
                    //MessageBox.Show("mail Send");
                }
                catch (Exception ex)
                {
                    Utilities.WriteLogError(ex);
                    //MessageBox.Show(ex.ToString());
                }
            }


        }

        public byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        }

    }
}
